#!/system/bin/sh
# Written By @tytydraco
# Modified by @Teixeirinha

ui_print "  ______                   "
ui_print " |___  /                   "
ui_print "    / /   ___  _   _  ___  "
ui_print "   / /   / _ \| | | |/ __| "
ui_print " ./ /___|  __/| |_| |\__ \ "
ui_print "  \_____/ \___| \__,_||___/"
ui_print "[*] developer: by @kodeka  "
ui_print "[*] Version:V6 Stable      "


##########################################################################################
# Permissions
##########################################################################################

set_permissions() {
  chmod 0755 $MODPATH/system/$b/*
}

##########################################################################################
# MMT Extended Logic - Don't modify anything after this
##########################################################################################

SKIPUNZIP=1
unzip -qjo "$ZIPFILE" 'common/functions.sh' -d $TMPDIR >&2
. $TMPDIR/functions.sh

set_perm_recursive "$MODPATH/system/bin" root root 0777 0755

# Do install-time script execution
# Written By @tytydraco
# Modified By @teixeirinha
sleep 2
ui_print "[*] Reboot System To Apply Functions"
sleep 2
ui_print "[*] Gaming Mode Better Assistant"
sleep 2
ui_print "[*] Todas As Alterações Na Changelog"
sleep 2
ui_print "[*] All Changelog Changes"
sleep 2